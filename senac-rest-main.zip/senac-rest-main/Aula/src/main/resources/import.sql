insert into tb_contatos(nome, email)values('maria','maria@gmail.com');
insert into tb_contatos(nome, email)values('joao','joao@gmail.com');
insert into tb_contatos(nome, email)values('pedro','pedro@gmail.com');